# Code in this file controls the behavior of auto-scale group.
from fortiflex import FortiFlex
from fortigate import FortiGateConfig
from fortianalyzer import FortiAnalyzerConfig
from database import FirestoreWrapper
from google.cloud import compute_v1
from google.cloud import storage
from utils import *
from vault import VAULT_ENABLE, vault_connect
import time
import base64
import json
import functions_framework

# Follwing parameters can control the behavior of this Cloud Function
# To overwrite the default value of the following parameters,
# you can use "cloud_function->additional_variables" in the terraform script:
# cloud_function = {
#   additional_variables = {
#     MANAGEMENT_PORT = "443"
#     DEFAULT_ROUTE_INTERFACE = "port1"
#     ...
#   }
# }
# **Overwriting parameters may cause unexpected behaviors!**
# To get advice on how to change the parameters to suit your custom needs,
# please create an GitHub issue at https://github.com/fortinetdev/terraform-google-cloud-modules

GLOBAL_ENV = {}

def load_global_env():
    global GLOBAL_ENV
    # Autoscale params
    GLOBAL_ENV["LICENSE_SOURCE"] = get_env_variable("LICENSE_SOURCE")
    GLOBAL_ENV["INSTANCE_PASSWORD"] = get_env_variable("INSTANCE_PASSWORD")
    GLOBAL_ENV["AUTOSCALE_PSKSECRET"] = get_env_variable("AUTOSCALE_PSKSECRET")
    GLOBAL_ENV["MANAGEMENT_PORT"] = get_env_variable("MANAGEMENT_PORT", "443")
    GLOBAL_ENV["HEALTHCHECK_PORT"] = get_env_variable("HEALTHCHECK_PORT", "8008")
    GLOBAL_ENV["BUCKET_NAME"] = get_env_variable("BUCKET_NAME", f"{PROJECT_PREFIX}-bucket")
    GLOBAL_ENV["API_USER_TOKEN"] = get_env_variable("API_USER_TOKEN", "")
    GLOBAL_ENV["ELB_IP_LIST"] = get_env_variable("ELB_IP_LIST", "[]")
    GLOBAL_ENV["ILB_IP_LIST"] = get_env_variable("ILB_IP_LIST", "[]")
    GLOBAL_ENV["DEFAULT_ROUTE_INTERFACE"] = get_env_variable("DEFAULT_ROUTE_INTERFACE", "port1") 
    GLOBAL_ENV["HA_SYNC_INTERFACE"] = get_env_variable("HA_SYNC_INTERFACE", "port2")
    GLOBAL_ENV["CLOUD_FUNC_INTERFACE"] = get_env_variable("CLOUD_FUNC_INTERFACE", "port1")
    GLOBAL_ENV["CLOUD_FUNC_IP_RANGE"] = get_env_variable("CLOUD_FUNC_IP_RANGE", "") # The ip range of this cloud function
    GLOBAL_ENV["FIRESTORE_DATABASE"] = get_env_variable("FIRESTORE_DATABASE", "(default)")
    GLOBAL_ENV["SKIP_CONFIG"] = get_env_variable("SKIP_CONFIG", "") # Allow you to skip some config steps.
    GLOBAL_ENV["PRIMARY_SCRIPT"] = get_env_variable("PRIMARY_SCRIPT", "") # Only the primary FGT runs this script.

    # Foriflex params
    GLOBAL_ENV["FORTIFLEX_CONFIG"] = get_env_variable("FORTIFLEX_CONFIG")
    GLOBAL_ENV["FORTIFLEX_USERNAME"] = get_env_variable("FORTIFLEX_USERNAME")
    GLOBAL_ENV["FORTIFLEX_PASSWORD"] = get_env_variable("FORTIFLEX_PASSWORD")
    GLOBAL_ENV["FORTIFLEX_RETRIEVE_MODE"] = get_env_variable("FORTIFLEX_RETRIEVE_MODE")
    GLOBAL_ENV["FORTIFLEX_CONCURRENT_MODE"] = True

    # FortiAnalyzer params
    GLOBAL_ENV["FAZ_IP"] = get_env_variable("FAZ_IP")
    GLOBAL_ENV["FAZ_ADOM"] = get_env_variable("FAZ_ADOM", "root")
    GLOBAL_ENV["FAZ_USERNAME"] = get_env_variable("FAZ_USERNAME", "admin")
    GLOBAL_ENV["FAZ_PASSWORD"] = get_env_variable("FAZ_PASSWORD")
    GLOBAL_ENV["FAZ_ACCESSTOKEN"] = get_env_variable("FAZ_ACCESSTOKEN")

def calculate_global_env():
    global GLOBAL_ENV
    GLOBAL_ENV["FAZ_ENABLE"] = False
    if GLOBAL_ENV["FAZ_IP"] and (GLOBAL_ENV["FAZ_PASSWORD"] or GLOBAL_ENV["FAZ_ACCESSTOKEN"]):
        GLOBAL_ENV["FAZ_ENABLE"] = True
    GLOBAL_ENV["SKIP_CONFIG_LIST"] = GLOBAL_ENV["SKIP_CONFIG"].split(",")
    if GLOBAL_ENV["FORTIFLEX_RETRIEVE_MODE"] == "use_activate": # accept misspelling is previous document & example
        GLOBAL_ENV["FORTIFLEX_RETRIEVE_MODE"] = "use_active"
    if GLOBAL_ENV["FORTIFLEX_RETRIEVE_MODE"] not in ["use_active", "use_stopped"]:
        GLOBAL_ENV["FORTIFLEX_RETRIEVE_MODE"] = "use_stopped"

def vault_load_global_env(log_header=""):
    """
    Connect to Vault and load sensitive parameters
    """
    global GLOBAL_ENV
    if not VAULT_ENABLE:
        return
    print_log(f"VAULT is enabled", "INFO", f"[{log_header}] [VAULT]")
    vault_data = vault_connect(log_header=f"[{log_header}] [VAULT]")
    if not isinstance(vault_data, dict):
        return
    # Overwrite global environment variables
    for key in vault_data:
        GLOBAL_ENV[key] = vault_data[key]

@functions_framework.cloud_event
def entry_point(cloud_event):
    print_log(f"Trigger Data: {cloud_event.data}", "TRACE")
    msg_raw_str = base64.b64decode(cloud_event.data["message"]["data"]).decode('utf-8')
    print_log(f"Trigger JSON Request: {msg_raw_str}", "TRACE")
    function_id = ""  # Used to identify different function threads
    msg_data = {}
    try:
        msg_data = json.loads(msg_raw_str)
        function_id = msg_data["protoPayload"]["resourceName"].split("/")[-1]
    except Exception as e:
        print_log(f"Unable to parse data into JSON: {msg_raw_str}, error: {e}", "ERROR")
        return
    if function_id.startswith(PROJECT_PREFIX + "-group"):
        method_name = msg_data["protoPayload"]["methodName"]
        print_log(f"Trigger: {method_name}. Cloud Function START.", "INFO", f"[{function_id}]")
        load_global_env()
        vault_load_global_env(function_id)  # Global variables can be overwritten by the Vault.
        calculate_global_env()
        cloud_function = FunctionWrapper(function_id, msg_data)
        cloud_function.run(method_name)
        print_log(f"Trigger: {method_name}. Cloud Function END.", "INFO", f"[{function_id}]")

class FunctionWrapper:
    def __init__(self, function_id, msg_data):
        self.msg_data = msg_data
        self.function_id = function_id
        self.project_id = msg_data["resource"]["labels"]["project_id"]
        self.db = FirestoreWrapper(self.project_id, PROJECT_PREFIX, database=GLOBAL_ENV["FIRESTORE_DATABASE"])

    def run(self, method_name):
        # Get task information
        # If get taskID, this task is triggered by this function.
        task_id = self.msg_data["protoPayload"].get("taskID", "")
        status = False
        task_data = {}
        if task_id:
            task_list_ref = self.db.collection_ref.document("GLOBAL").collection("TASK_LIST")
            task_data = self.db.read_document(task_id, collection_ref=task_list_ref)
        # Run task
        if method_name.endswith("compute.instances.insert") or method_name.endswith("compute.instances.update"):
            instance_name = self.msg_data["protoPayload"]["resourceName"].split("/")[-1]
            instance_id = self.msg_data["resource"]["labels"]["instance_id"]
            status = self.instance_insert(instance_name, instance_id)
        elif method_name.endswith("compute.instances.delete"):
            instance_name = self.msg_data["protoPayload"]["resourceName"].split("/")[-1]
            status = self.instance_delete(instance_name)
        elif method_name == "faz_connection":
            serial_number = task_data["params"]["serial_number"]
            status = self.task_faz_connection(serial_number)
        else:
            self.print(f"Unknown method: {method_name}. Do nothing.", "WARN")
        # Do post steps
        if task_id:
            task_list_ref = self.db.collection_ref.document("GLOBAL").collection("TASK_LIST")
            if status:
                self.print(f"[{task_id}]: Success. Remove this task from the TASK_LIST.", "DEBUG")
                self.db.delete_document(task_id, collection_ref=task_list_ref)
            else:
                self.print(f"[{task_id}]: Fail. Retrigger the task.", "DEBUG")
                retry_count = task_data.get("retry_count", 0) + 1
                self.db.update_document(task_id, {"retry_count": retry_count}, collection_ref=task_list_ref)
                trigger_data = self.msg_data
                time.sleep(1)
                pubsub_id = self.publish_to_pubsub(trigger_data)
                self.print(f"Send pubsub task: {task_id} {pubsub_id}", "DEBUG")
                self.print(f"Send pubsub data: {trigger_data}", "TRACE")

    def upgrade_database(self):
        """
        Update database due to upgrade. E.g, Project version 1.0.0 -> 1.1.0
        """
        lock_status, global_data = self.db.lock("GLOBAL", self.function_id)
        self.db.update_document("GLOBAL", {
            "default_route_interface": GLOBAL_ENV["DEFAULT_ROUTE_INTERFACE"],
            "ha_sync_interface": GLOBAL_ENV["HA_SYNC_INTERFACE"],
            "cloud_func_interface": GLOBAL_ENV["CLOUD_FUNC_INTERFACE"],
            "elb_ip_list": parse_json_str(GLOBAL_ENV["ELB_IP_LIST"], []),
            "ilb_ip_list": parse_json_str(GLOBAL_ENV["ILB_IP_LIST"], []),
            "cloud_func_version": CLOUD_FUNC_VERSION})
        self.db.unlock("GLOBAL", self.function_id)

    def instance_insert(self, instance_name, instance_id):
        """
        Update database, inject license when new instance is created.
        """
        # Get instance meta information
        compute_client = compute_v1.InstancesClient()
        instance = None
        try:
            zone = self.msg_data["resource"]["labels"]["zone"]
            instance = compute_client.get(project=self.project_id, zone=zone, instance=instance_id)
        except Exception as e:
            self.print(f"Can't get instance meta data: {e}", "ERROR")
        if instance is None:
            return False
        # If this instance data already existed in the database, this is an update task instead of a create task.
        behavior = "insert"
        if self.db.read_document(instance_name):
            behavior = "update"
        is_primary = False
        timestamp = time.time()
        # Updata database
        instance_ip_list = [item.network_i_p for item in instance.network_interfaces]
        global_data = self.db.read_document("GLOBAL")
        if not global_data:
            global_data = {
                "primary_ip_list": instance_ip_list,
                "primary_instance_name": instance_name,
                "primary_instance_id": instance_id,
                # Currently, the following data in global_data is only for display purposes.
                # The actual variable values ​​are obtained from the environment variables of this cloud function.
                "license_source": GLOBAL_ENV["LICENSE_SOURCE"],
                "default_route_interface": GLOBAL_ENV["DEFAULT_ROUTE_INTERFACE"],
                "ha_sync_interface": GLOBAL_ENV["HA_SYNC_INTERFACE"],
                "cloud_func_interface": GLOBAL_ENV["CLOUD_FUNC_INTERFACE"],
                "elb_ip_list": parse_json_str(GLOBAL_ENV["ELB_IP_LIST"], []),
                "ilb_ip_list": parse_json_str(GLOBAL_ENV["ILB_IP_LIST"], []),
                "cloud_func_version": CLOUD_FUNC_VERSION
            }
            self.db.create_document("GLOBAL", global_data)
        # Avoid more than 1 instance try to become primary. Wait and get it again.
        # non-primary FGT also need to sleep, just in case GLOBAL is updated.
        time.sleep(0.5)
        global_data = self.db.read_document("GLOBAL")
        if global_data["primary_instance_name"] == instance_name:
            is_primary = True
            self.update_global_license_file_status()
        # Update dasebase due to project upgrade
        need_upgrade = compare_versions(global_data.get("cloud_func_version", "1.0.0"), CLOUD_FUNC_VERSION)
        if need_upgrade:
            self.upgrade_database()

        instance_data = {
                        "instance_id": instance_id,
                        "instance_ip_list": instance_ip_list,
                        "is_primary": is_primary,
                        "timestamp": timestamp
                        }
        if behavior == "insert":
            self.db.create_document(instance_name, instance_data)
        elif behavior == "update":
            self.db.update_document(instance_name, instance_data)
            instance_data = self.db.read_document(instance_name)
        cloud_func_port_id = get_port_id(GLOBAL_ENV["CLOUD_FUNC_INTERFACE"], 0)
        config_module = FortiGateConfig(instance_ip_list[cloud_func_port_id], instance_name, login_port=GLOBAL_ENV["MANAGEMENT_PORT"],
                                        log_level=LOGGING_LEVEL, username="admin", password=GLOBAL_ENV["INSTANCE_PASSWORD"])
        status, response = config_module.change_init_password(instance_id, GLOBAL_ENV["INSTANCE_PASSWORD"])
        self.print(f"[Task change password] Status: {status}", "INFO")

        # Upload license
        if GLOBAL_ENV["LICENSE_SOURCE"] in ["fortiflex", "file", "file_fortiflex"]:
            if GLOBAL_ENV["LICENSE_SOURCE"] in ["file", "file_fortiflex"]:
                pre_assigned_file = instance_data.get("license_file", "")
                status, license_data = self.file_license_assign(instance_name, pre_assigned_file)
                if status:
                    status, response = config_module.upload_license("file", license_data)
            if GLOBAL_ENV["LICENSE_SOURCE"] == "fortiflex" or (GLOBAL_ENV["LICENSE_SOURCE"] == "file_fortiflex" and not status):
                foritflex = FortiFlex(username=GLOBAL_ENV["FORTIFLEX_USERNAME"],
                                      password=GLOBAL_ENV["FORTIFLEX_PASSWORD"],
                                      task_name="GCP:"+instance_name)
                entitlement = {}
                pre_assigned_serial_number = instance_data.get("serial_number", "")
                if pre_assigned_serial_number:
                    self.print(f"Using previous serial number {pre_assigned_serial_number}", "DEBUG")
                    entitlement = foritflex.refresh_token(pre_assigned_serial_number)
                if not entitlement:
                    entitlement = foritflex.retrieve_unused_entitlement(GLOBAL_ENV["FORTIFLEX_CONFIG"], mode=GLOBAL_ENV["FORTIFLEX_RETRIEVE_MODE"], concurrent_mode=GLOBAL_ENV["FORTIFLEX_CONCURRENT_MODE"])
                status = (entitlement != {})
                self.print(f"Get entitlement {entitlement}", "TRACE")
                if status:
                    license_data = entitlement["token"]
                    self.db.update_document(instance_name, {"serial_number": entitlement["serialNumber"],
                                                            "config_id": entitlement["configId"],
                                                            "license_source": "fortiflex"})
                    status, response = config_module.upload_license("fortiflex", license_data)
            self.print(f"[Task upload license] Status: {status}", "INFO")

            if not status:
                self.print("License injection fail, cloud function stopped.", "ERROR")
                return False
            self.print("FGT rebooting, sleep 80s", "INFO")
            time.sleep(80)

        # Configuration data
        return self.upload_fgt_init_config(instance_name, instance, config_module, is_primary)

    def instance_delete(self, instance_name):
        """   
        Update database, release license when instance is deleted.
        """
        # Update dasebase due to project upgrade
        global_data = self.db.read_document("GLOBAL")
        need_upgrade = compare_versions(global_data.get("cloud_func_version", "1.0.0"), CLOUD_FUNC_VERSION)
        if need_upgrade:
            self.upgrade_database()
        instance_data = self.db.read_document(instance_name)
        # Release license
        license_source = instance_data.get("license_source", "")
        if license_source == "fortiflex": # Release fortiflex token
            config_id = instance_data.get("config_id", "")
            serial_number = instance_data.get("serial_number", "")
            foritflex = FortiFlex(username=GLOBAL_ENV["FORTIFLEX_USERNAME"],
                                  password=GLOBAL_ENV["FORTIFLEX_PASSWORD"],
                                  task_name="GCP:"+instance_name)
            entitlement = foritflex.get_entitlement(config_id, serial_number=serial_number)
            if not entitlement:
                self.print(f"Unable to find serial number {serial_number} in the fortiflex. Will try to qurey the serial number by using description.", "WARN")
                entitlement = foritflex.get_entitlement(GLOBAL_ENV["FORTIFLEX_CONFIG"], description="GCP:"+instance_name)
                if entitlement:
                    config_id = entitlement.get("configId", "")
                    serial_number = entitlement.get("serialNumber", "")
            if entitlement:
                foritflex.release_used_entitlement(serial_number, config_id, mode=GLOBAL_ENV["FORTIFLEX_RETRIEVE_MODE"], concurrent_mode=GLOBAL_ENV["FORTIFLEX_CONCURRENT_MODE"])
                self.print(f"Release instance foritflex token, done.", "INFO")
        elif license_source == "file": # Release license file
            status = self.file_license_release(instance_name, instance_data)
            self.print(f"Release instance license file {status}", "INFO")
        # Delete firestore database
        self.db.delete_document(instance_name)
        task_list_ref = self.db.collection_ref.document("GLOBAL").collection("TASK_LIST")
        task_data_list = task_list_ref.stream()
        delete_task_list = []
        for task_data in task_data_list:
            task_id = task_data.id
            task_data = task_data.to_dict()
            if instance_name == task_data.get("creator"):
                delete_task_list.append(task_id)
        for delete_task in delete_task_list:
            self.db.delete_document(delete_task, task_list_ref)
        # disconnect from faz/fmg
        if GLOBAL_ENV["FAZ_ENABLE"]:
            # TODO What if task failed? retry?
            serial_number = instance_data.get("serial_number", "")
            if serial_number:
                self.task_faz_disconnect(serial_number)
        # If the global data is the only thing left behind, delete the whole dataset
        current_doc_number = self.db.get_document_number()
        if current_doc_number==1 and self.db.read_document("GLOBAL"):
            self.db.delete_collection(task_list_ref)
            self.db.delete_document("GLOBAL")
        # If this instance is primary, reselect primary.
        delete_primary = instance_data.get("is_primary", False)
        if delete_primary and current_doc_number>1:            
            # Wait 10 seconds. If other instances are also shut down, the other
            # Cloud Functions threads will delete them from the database within 10 seconds.
            time.sleep(10)
            new_primary_data = None
            while new_primary_data is None:
                if self.db.get_document_number()>1:
                    self.print(f"Reselect primary start.", "INFO")
                    status, reselect_primary_id = self.reselect_primary_fgt()
                    self.print(f"Reselect primary {status}, new primary: {reselect_primary_id}.", "INFO")
                    if not status:
                        self.print(f"Failed in reselect primary. Restart primary selection.", "INFO")
                        continue
                    # restart the selection if the new primary is also been deleted.
                    if reselect_primary_id:
                        new_primary_data = self.db.read_document(reselect_primary_id)
                    if new_primary_data is None:
                        self.print(f"New primary {reselect_primary_id} does not exist. Restart primary selection.", "INFO")
        self.print(f"Release instance finished.", "INFO")
        return True

    def upload_fgt_init_config(self, instance_name, instance, config_module, is_primary):
        config_data = "# Following code updated by cloud functions\n"
        # Load meta data
        subnetwork_client = compute_v1.SubnetworksClient()
        interface_list = []
        for i, interface in enumerate(instance.network_interfaces):
            subnet_self_link = interface.subnetwork
            subnetwork_region = get_key_from_url(subnet_self_link, "regions")
            subnetwork_name = get_key_from_url(subnet_self_link, "subnetworks")
            subnetwork = subnetwork_client.get(project=self.project_id, region=subnetwork_region, subnetwork=subnetwork_name)
            interface_list.append({"ip_cidr_range": subnetwork.ip_cidr_range,
                                   "gateway_address": subnetwork.gateway_address,
                                   "subnet_name": subnetwork.name,
                                   "network_ip": interface.network_i_p,
                                   "port": "port"+str(i+1)})
        global_data = self.db.read_document("GLOBAL")
        ilb_ip_list = parse_json_str(GLOBAL_ENV["ILB_IP_LIST"], [])
        elb_ip_list = parse_json_str(GLOBAL_ENV["ELB_IP_LIST"], [])
        for i, interface in enumerate(instance.network_interfaces):
            ilb_ip = get_list_element(ilb_ip_list, i, "")
            if ilb_ip:
                interface_list[i]["ilb_ip"] = ilb_ip
            elb_ip = get_list_element(elb_ip_list, i, "")
            if elb_ip:
                interface_list[i]["elb_ip"] = elb_ip
        # Try to parse interface data
        user_script = ""
        for key_value in instance.metadata.items:
            if key_value.key == "user-data":
                user_script = key_value.value
        user_script_list = [line.split("#")[0].strip() for line in user_script.split("\n")]
        user_script_list = [line for line in user_script_list if line!=""]
        interface_list = parse_interface_allowaccess(user_script_list, interface_list)

        ha_port_id = get_port_id(GLOBAL_ENV["HA_SYNC_INTERFACE"], 1)
        primary_sync_ip = global_data["primary_ip_list"][ha_port_id]
        if is_primary:
            config_data += GLOBAL_ENV["PRIMARY_SCRIPT"] + "\n"
        config_data += config_system_autoscale(is_primary, GLOBAL_ENV["HA_SYNC_INTERFACE"], primary_sync_ip)
        config_data += config_system_interface(interface_list)
        config_data += config_router_static(interface_list, user_script_list)
        config_data += config_api_user()
        config_data += config_faz_connection()
        self.print(f"[Config data] {config_data}", "DEBUG")
        status, response = config_module.upload_config(config_data)
        self.print(f"[Task upload config] Status: {status}", "INFO")
        self.db.update_document(instance_name, {"upload_config_status": status})

        # In some special case, the fortiflex serial number and real FGT serial number are different.
        # serial_number here is real FGT serial number
        serial_number = ""
        try:
            response_json = json.loads(response.text)
            serial_number = response_json["serial"]
            self.db.update_document(instance_name, {"serial_number": serial_number})
        except Exception as e:
            self.print(f"Unable to update serial_number information in the database {e}", "ERROR")

        if GLOBAL_ENV["FAZ_ENABLE"]:
            status = self.task_faz_connection(serial_number)
            if not status:
                # Create special task
                params = {"serial_number": serial_number}
                self.create_task("faz_connection", params)
        return True

    def create_task(self, task_type, params=None):
        task_list_ref = self.db.collection_ref.document("GLOBAL").collection("TASK_LIST")
        timestamp = time.time()
        task_data = {
            "creator": self.function_id,
            "task_type": task_type,
            "status": "pending", # pending, active, error?
            "created_at": timestamp,
            "retry_count": 0,
        }
        if params:
            task_data["params"] = params
        doc_ref = task_list_ref.document()
        doc_ref.set(task_data)
        trigger_data = {}
        trigger_data["resource"] = self.msg_data["resource"]
        trigger_data["protoPayload"] = {
            "resourceName": self.msg_data["protoPayload"]["resourceName"],
            "methodName": task_type,
            "taskID": doc_ref.id
        }
        pubsub_id = self.publish_to_pubsub(trigger_data)
        self.print(f"Send pubsub task: {pubsub_id}", "DEBUG")
        self.print(f"Send pubsub data: {trigger_data}", "TRACE")

    def file_license_assign(self, instance_name, pre_assigned_file=""):
        """
        Assign license for current instance, and return license data.
        """
        if pre_assigned_file != "":
            storage_client = storage.Client(project=self.project_id)
            bucket = storage_client.get_bucket(GLOBAL_ENV["BUCKET_NAME"])
            license_data = bucket.blob(pre_assigned_file).download_as_bytes()
            if license_data != "":
                return True, license_data
        lock_status, global_data = self.db.lock("GLOBAL", self.function_id)
        if not lock_status or not isinstance(global_data, dict):
            return False, ""
        license_file_status = global_data.get("license_file_status")
        license_data = ""
        for license_file, owner_id in license_file_status.items():
            if owner_id == "":
                target_file = license_file
                license_file_status[license_file] = instance_name
                self.db.update_document("GLOBAL", {"license_file_status": license_file_status})
                self.db.update_document(instance_name, {"license_file": target_file, "license_source": "file"})
                storage_client = storage.Client(project=self.project_id)
                bucket = storage_client.get_bucket(GLOBAL_ENV["BUCKET_NAME"])
                license_data = bucket.blob(target_file).download_as_bytes()
                break
        self.db.unlock("GLOBAL", self.function_id)
        return license_data!="", license_data

    def file_license_release(self, instance_name, instance_data={}):
        if not instance_data:
            instance_data = self.db.read_document(instance_name)
            if not instance_data:
                return False
        license_file = instance_data.get("license_file", "")
        self.db.update_document(instance_name, {"license_file": ""})
        if license_file:
            lock_status, global_data = self.db.lock("GLOBAL", self.function_id)
            if not lock_status or not isinstance(global_data, dict):
                return False
            license_file_status = global_data.get("license_file_status", {})
            license_file_status[license_file] = ""
            # Go through the whole list, just to avoid more than one license files are assigned to this instance due to some strange Bugs.            
            for license_file_name, owner_id in license_file_status.items():
                if owner_id == instance_name:
                    license_file_status[license_file_name] = ""
            self.db.update_document("GLOBAL", {"license_file_status": license_file_status})
            self.db.unlock("GLOBAL", self.function_id)
        return True

    def reselect_primary_fgt(self):
        """
        If the primary FGT is destroyed, reselect a new primary based on created time.
        """
        lock_status, global_data = self.db.lock("GLOBAL", self.function_id)
        if not lock_status or not isinstance(global_data, dict):
            return False, ""

        new_primary_fgt_name = ""
        new_primary_fgt_id = ""
        primary_sync_ip = ""
        least_time = float("+inf")
        docs = self.db.collection_ref.get()
        # Selete new primary FGT
        for doc in docs:
            if doc.id == "GLOBAL":
                continue
            instance_creation_time = doc.to_dict().get("timestamp", float("+inf"))
            instance_creation_time = float(instance_creation_time)
            if instance_creation_time < least_time:
                least_time = instance_creation_time
                new_primary_fgt_name = doc.id
                new_primary_fgt_id = doc.to_dict().get("instance_id", "")
        if not new_primary_fgt_name:
            return False, ""
        # Update firestore database
        instance_data = self.db.read_document(new_primary_fgt_name)
        instance_ip_list = instance_data.get("instance_ip_list", [""]*8)
        ha_port_id = get_port_id(GLOBAL_ENV["HA_SYNC_INTERFACE"], 1)
        primary_sync_ip = instance_ip_list[ha_port_id]
        self.db.update_document("GLOBAL", {"primary_instance_id": new_primary_fgt_id,
                                            "primary_instance_name": new_primary_fgt_name,
                                            "primary_ip_list": instance_ip_list})
        self.db.update_document(new_primary_fgt_name, {"is_primary": True})
        self.db.unlock("GLOBAL", self.function_id)
        # Reupload config
        import threading
        import queue
        threads = []
        result_queue = queue.Queue() # This queue is thread-safe
        for doc in docs:
            if doc.id == "GLOBAL":
                continue
            instance_data = doc.to_dict()
            if "upload_config_status" not in doc.to_dict():
                # This is new instance. It will be updated in upload_fgt_init_config function
                continue
            instance_name = str(doc.id)
            is_primary = (new_primary_fgt_name==doc.id)
            thread = threading.Thread(target=self.thread_reselect_primary_upload_config,
                                        args=(instance_name, instance_data, is_primary, primary_sync_ip, result_queue))
            threads.append(thread)
            thread.start()
        for thread in threads:
            thread.join()
        error_fgts = []
        while not result_queue.empty():
            instance_name, status, response = result_queue.get()
            if not status:
                error_fgts.append(instance_name)
                self.print(f"Reselection error {instance_name}, {response}.", "ERROR")
        return len(error_fgts)==0, new_primary_fgt_name
    
    def thread_reselect_primary_upload_config(self, instance_name, instance_data, is_primary, primary_sync_ip, result_queue):
        instance_ip_list = instance_data.get("instance_ip_list", "")
        cloud_func_port_id = get_port_id(GLOBAL_ENV["CLOUD_FUNC_INTERFACE"], 0)
        config_module = FortiGateConfig(instance_ip_list[cloud_func_port_id], "ReselectPrimary-" + instance_name, login_port=GLOBAL_ENV["MANAGEMENT_PORT"],
                                        log_level=LOGGING_LEVEL, username="admin", password=GLOBAL_ENV["INSTANCE_PASSWORD"],
                                        api_token=GLOBAL_ENV["API_USER_TOKEN"])
        config_data = config_system_autoscale(is_primary, GLOBAL_ENV["HA_SYNC_INTERFACE"], primary_sync_ip)
        status, response = config_module.upload_config(config_data)
        result_queue.put((instance_name, status, response)) # This behavior is thread-safe.
        return status, response

    def update_global_license_file_status(self):
        storage_client = storage.Client(project=self.project_id)
        bucket = storage_client.get_bucket(GLOBAL_ENV["BUCKET_NAME"])
        license_file_status = {}
        blobs = bucket.list_blobs()
        for blob in blobs:
            file_path = blob.name
            if file_path.startswith("licenses/"):
                license_file_status[file_path] = ""
        self.db.update_document("GLOBAL", {"license_file_status": license_file_status})

    def task_faz_connection(self, serial_number):
        faz = FortiAnalyzerConfig(GLOBAL_ENV["FAZ_IP"],
            username = GLOBAL_ENV["FAZ_USERNAME"],
            password= GLOBAL_ENV["FAZ_PASSWORD"],
            log_level = LOGGING_LEVEL,
            log_header = self.function_id,
            access_token =  GLOBAL_ENV["FAZ_ACCESSTOKEN"]
        )
        api_rc, response_json = faz.task_add_device(serial_number, faz_adom=GLOBAL_ENV["FAZ_ADOM"])
        return api_rc==0

    def task_faz_disconnect(self, serial_number):
        faz = FortiAnalyzerConfig(GLOBAL_ENV["FAZ_IP"],
            username = GLOBAL_ENV["FAZ_USERNAME"],
            password= GLOBAL_ENV["FAZ_PASSWORD"],
            log_level = LOGGING_LEVEL,
            log_header = self.function_id,
            access_token =  GLOBAL_ENV["FAZ_ACCESSTOKEN"]
        )
        api_rc, response_json = faz.task_delete_device(serial_number, faz_adom=GLOBAL_ENV["FAZ_ADOM"])
        return api_rc==0

    def publish_to_pubsub(self, data):
        from google.cloud import pubsub_v1
        try:
            publisher = pubsub_v1.PublisherClient()
            topic_path = publisher.topic_path(self.project_id, f"{PROJECT_PREFIX}-topic")
            message_data = json.dumps(data).encode("utf-8")
            future = publisher.publish(topic_path, message_data)
            return future.result()
        except Exception as e:
            self.print(f"Can't send pubsub data {e}.", "ERROR")
            return -1

    def print(self, print_str, log_level="INFO"):
        print_log(print_str, log_level, f"[{self.function_id}]")

# Update config data
def config_system_autoscale(is_primary, ha_sync_interface, primary_sync_ip=""):
    if "autoscale" in GLOBAL_ENV["SKIP_CONFIG_LIST"]:
        return ""
    config_data = f"config system auto-scale\n"
    config_data += f"    set status enable\n"
    config_data += f"    set sync-interface {ha_sync_interface}\n"
    if is_primary:
        config_data += f"    set role primary\n"
    else:
        config_data += f"    set role secondary\n"
        config_data += f"    set primary-ip {primary_sync_ip}\n"
    if GLOBAL_ENV["AUTOSCALE_PSKSECRET"] != "":
        config_data += f"    set psksecret '{GLOBAL_ENV["AUTOSCALE_PSKSECRET"]}'\n"
    config_data += f"end\n"
    return config_data

def config_system_interface(interface_list):
    config_data = f"config system interface\n"
    for interface_info in interface_list:
        config_data += f"    edit {interface_info['port']}\n"
        config_data += f"        set mode static\n"
        config_data += f"        set ip {interface_info['network_ip']}/32\n"
        if "allowaccess" in interface_info:
            config_data += f"        " + interface_info["allowaccess"] + "\n"
        else:
            config_data += f"        set allowaccess ping https ssh http fgfm probe-response\n"
        secondary_ip = interface_info.get("elb_ip", interface_info.get("ilb_ip", ""))
        if secondary_ip:
            config_data += f"        set secondary-IP enable\n"
            config_data += f"        config secondaryip\n"
            config_data += f"            edit 0\n"
            config_data += f"                set ip {secondary_ip}/32\n"
            config_data += f"                set allowaccess ping probe-response\n"
            config_data += f"            next\n"
            config_data += f"        end\n"
        config_data += f"    next\n"
    config_data += f"end\n"
    if GLOBAL_ENV["HEALTHCHECK_PORT"] != "0":
        config_data += f"config system probe-response\n"
        config_data += f"    set mode http-probe\n"
        config_data += f"    set port {GLOBAL_ENV["HEALTHCHECK_PORT"]}\n"
        config_data += f"end\n"
    return config_data

def config_router_static(interface_list, user_script_list):
    def append_router_data(router_data):
        # Only append this router data if it is not exist before
        tmp_router = {k: router_data[k] for k in router_data if k != "comment"}
        # TODO improve compare "192.168.0.1/32" & "192.168.0.1 255.255.255.255"
        if tmp_router not in existing_router:
            existing_router.append(tmp_router)
            router_list.append(router_data)

    existing_router = parse_router_static(user_script_list)
    router_list = []
    for interface_info in interface_list:
        if interface_info["port"] == GLOBAL_ENV["DEFAULT_ROUTE_INTERFACE"]:
            append_router_data({"device": interface_info["port"],
                                "gateway": interface_info["gateway_address"],
                                "comment": "Default route. (Created by cloud function)"})
        if interface_info.get("ilb_ip", ""):
            append_router_data({"dst": "35.191.0.0/16",
                                "device": interface_info["port"],
                                "gateway": interface_info["gateway_address"],
                                "comment": "Used for ilb health check. (Created by cloud function)"})
            append_router_data({"dst": "130.211.0.0/22",
                                "device": interface_info["port"],
                                "gateway": interface_info["gateway_address"],
                                "comment": "Used for ilb health check. (Created by cloud function)"})
        elif interface_info["port"] == "port1" and GLOBAL_ENV["HEALTHCHECK_PORT"] != "0" and GLOBAL_ENV["DEFAULT_ROUTE_INTERFACE"] != "port1":
            append_router_data({"dst": "35.191.0.0/16",
                                "device": interface_info["port"],
                                "gateway": interface_info["gateway_address"],
                                "comment": "Used for autohealing health check. (Created by cloud function)"})
            append_router_data({"dst": "130.211.0.0/22",
                                "device": interface_info["port"],
                                "gateway": interface_info["gateway_address"],
                                "comment": "Used for autohealing health check. (Created by cloud function)"})
        if interface_info["port"] == GLOBAL_ENV["CLOUD_FUNC_INTERFACE"] and GLOBAL_ENV["CLOUD_FUNC_IP_RANGE"] != "":
            append_router_data({"dst": GLOBAL_ENV["CLOUD_FUNC_IP_RANGE"],
                                "device": interface_info["port"],
                                "gateway": interface_info["gateway_address"],
                                "comment": "Reply cloud function. (Created by cloud function)"})
        append_router_data({"dst": interface_info["ip_cidr_range"],
                            "device": interface_info["port"],
                            "gateway": interface_info["gateway_address"],
                            "comment": "Route for this interface. (Created by cloud function)"})    
    config_data = f"config router static\n"
    for router_data in router_list:
        config_data += f"    edit 0\n"
        for key, value in router_data.items():
             config_data += f"        set {key} \"{value}\"\n"
        config_data += f"    next\n"
    config_data += f"end\n"
    return config_data

def config_api_user():
    config_data = ""
    if GLOBAL_ENV["API_USER_TOKEN"]:
        config_data += f"config system api-user\n"
        config_data += f"    edit gcp_function_user\n"
        config_data += f"        set comments \"GCP Cloud Functions uses this user for autoscaling configuration.\"\n"
        config_data += f"        set api-key {GLOBAL_ENV["API_USER_TOKEN"]}\n"
        config_data += f"    next\n"
        config_data += f"end\n"
    return config_data

def config_faz_connection():
    config_data = ""
    if GLOBAL_ENV["FAZ_ENABLE"]:
        config_data += f"config log fortianalyzer setting\n"
        config_data += f"    set status enable\n"
        config_data += f"    set server \"{GLOBAL_ENV["FAZ_IP"]}\"\n"
        config_data += f"    set certificate-verification disable\n"
        config_data += f"    set upload-option realtime\n"
        config_data += f"    set reliable enable\n"
        config_data += f"end\n"
    return config_data

def parse_interface_allowaccess(user_script_list, interface_list):
    try:
        search_flag = False
        current_port = -1
        for line in user_script_list:
            line = ' '.join(line.split()) # remove extra space
            if line == "config system interface":
                search_flag = True
                continue
            if search_flag:
                if line == "end":
                    search_flag = False
                    current_port = -1
                elif line.startswith("edit port"):
                    current_port = int(line[len("edit port"):]) - 1
                elif line.startswith("set allowaccess"):
                    if "probe-response" not in line:
                        line += " probe-response"
                    if 0 <= current_port < len(interface_list):
                        interface_list[current_port]["allowaccess"] = line
    except:
        pass
    return interface_list

def parse_router_static(user_script_list):
    search_flag = False
    router_list = []
    router_data = {}
    try:
        for line in user_script_list:
            if line == "config router static":
                search_flag = True
                continue
            if search_flag:
                if line == "end":
                    search_flag = False
                    if len(router_data):
                        router_list.append(router_data)
                        router_data = {}                        
                elif line == "next":
                    if len(router_data):
                        router_list.append(router_data)
                        router_data = {}
                elif line.startswith("edit "):
                    router_data = {}
                elif line.startswith("set "):
                    line_split = [item.strip("\"") for item in line.split(" ") if item!=""]
                    if len(line_split)==3:
                        _, key, value = line_split
                        router_data[key] = value
    except:
        pass
    return router_list
    
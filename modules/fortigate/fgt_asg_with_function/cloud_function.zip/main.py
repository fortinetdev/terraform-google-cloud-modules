# Code in this file controls the behavior of auto-scale group.
from fortiflex import FortiFlex
from fortigate import FortiGateConfig
from database import FirestoreWrapper
from google.cloud import compute_v1
from google.cloud import storage
from utils import *
import time
import base64
import json
import functions_framework

# Autoscale params
LICENSE_SOURCE = get_env_variable("LICENSE_SOURCE")
INSTANCE_PASSWORD = get_env_variable("INSTANCE_PASSWORD")
AUTOSCALE_PSKSECRET = get_env_variable("AUTOSCALE_PSKSECRET")
MANAGEMENT_PORT = get_env_variable("MANAGEMENT_PORT", 443)
BUCKET_NAME = get_env_variable("BUCKET_NAME", f"{PROJECT_PREFIX}-bucket")
API_USER_TOKEN = get_env_variable("API_USER_TOKEN", "")
ELB_IP_LIST = get_env_variable("ELB_IP_LIST", "[]")
ILB_IP_LIST = get_env_variable("ILB_IP_LIST", "[]")
DEFAULT_ROUTE_INTERFACE = get_env_variable("DEFAULT_ROUTE_INTERFACE", "port1") 
HA_SYNC_INTERFACE = get_env_variable("HA_SYNC_INTERFACE", "port2")
CLOUD_FUNC_INTERFACE = get_env_variable("CLOUD_FUNC_INTERFACE", "port1")
FIRESTORE_DATABASE = get_env_variable("FIRESTORE_DATABASE", "(default)")
# Foriflex params
FORTIFLEX_CONFIG = get_env_variable("FORTIFLEX_CONFIG")
FORTIFLEX_USERNAME = get_env_variable("FORTIFLEX_USERNAME")
FORTIFLEX_PASSWORD = get_env_variable("FORTIFLEX_PASSWORD")
FORTIFLEX_RETRIEVE_MODE = get_env_variable("FORTIFLEX_RETRIEVE_MODE")
if FORTIFLEX_RETRIEVE_MODE == "use_activate": # accept misspelling is previous document & example
    FORTIFLEX_RETRIEVE_MODE = "use_active"
if FORTIFLEX_RETRIEVE_MODE not in ["use_active", "use_stopped"]:
    FORTIFLEX_RETRIEVE_MODE = "use_stopped"
FORTIFLEX_CONCURRENT_MODE = True

@functions_framework.cloud_event
def entry_point(cloud_event):
    msg_raw_str = base64.b64decode(cloud_event.data["message"]["data"]).decode('utf-8')
    msg_data = json.loads(msg_raw_str)
    instance_name = msg_data["protoPayload"]["resourceName"].split("/")[-1]
    print_log("[{}] Trigger cloud function".format(instance_name), "INFO")
    if instance_name.startswith(PROJECT_PREFIX + "-group"):
        cloud_function = FunctionWrapper(msg_data)
        method_name = msg_data["protoPayload"]["methodName"]
        if method_name.endswith("compute.instances.insert") or method_name.endswith("compute.instances.update"):
            cloud_function.instance_insert()
        elif method_name.endswith("compute.instances.delete"):
            cloud_function.instance_delete()
    print_log("[{}] DONE".format(instance_name), "INFO")

class FunctionWrapper:
    def __init__(self, msg_data):
        self.msg_data = msg_data
        self.resource_name = msg_data["protoPayload"]["resourceName"]
        self.instance_name = msg_data["protoPayload"]["resourceName"].split("/")[-1]
        self.instance_id = msg_data["resource"]["labels"]["instance_id"]
        self.project_id = msg_data["resource"]["labels"]["project_id"]
        self.zone = msg_data["resource"]["labels"]["zone"]
        self.region = self.zone.rpartition("-")[0]
        self.db = FirestoreWrapper(self.project_id, PROJECT_PREFIX, database=FIRESTORE_DATABASE)
        
    def upgrade_database(self):
        """
        Update database due to upgrade. E.g, Project version 1.0.0 -> 1.1.0
        """
        
        lock_status, global_data = self.db.lock("GLOBAL", self.instance_name)
        self.db.update_document("GLOBAL", {
            "default_route_interface": DEFAULT_ROUTE_INTERFACE,
            "ha_sync_interface": HA_SYNC_INTERFACE,
            "cloud_func_interface": CLOUD_FUNC_INTERFACE,
            "elb_ip_list": parse_json_str(ELB_IP_LIST, []),
            "ilb_ip_list": parse_json_str(ILB_IP_LIST, []),
            "cloud_func_version": CLOUD_FUNC_VERSION})
        self.db.unlock("GLOBAL", self.instance_name)

    def instance_insert(self):
        """
        Update database, inject license when new instance is created.
        """
        compute_client = compute_v1.InstancesClient()
        instance = compute_client.get(project=self.project_id, zone=self.zone, instance=self.instance_id)
        behavior = "insert"
        if self.db.get_document(self.instance_name):
            behavior = "update"
        # Data decided by this function
        is_primary = False
        timestamp = time.time()

        # Updata database
        instance_ip_list = [item.network_i_p for item in instance.network_interfaces]
        global_data = self.db.get_document("GLOBAL")
        if not global_data:
            global_data = {
                "primary_ip_list": instance_ip_list,
                "primary_instance_name": self.instance_name,
                "primary_instance_id": self.instance_id,
                # Currently, the following data in global data is only for display purposes.
                # The actual variable values ​​are obtained from the environment variables of this cloud function.
                "license_source": LICENSE_SOURCE,
                "default_route_interface": DEFAULT_ROUTE_INTERFACE,
                "ha_sync_interface": HA_SYNC_INTERFACE,
                "cloud_func_interface": CLOUD_FUNC_INTERFACE,
                "elb_ip_list": parse_json_str(ELB_IP_LIST, []),
                "ilb_ip_list": parse_json_str(ILB_IP_LIST, []),
                "cloud_func_version": CLOUD_FUNC_VERSION
            }
            self.db.add_document("GLOBAL", global_data)
        # Avoid more than 1 instance try to become primary. Wait and get it again.
        # non-primary FGT also need to sleep, just in case GLOBAL is updated.
        time.sleep(0.5)
        global_data = self.db.get_document("GLOBAL")
        if global_data["primary_instance_name"] == self.instance_name:
            is_primary = True
            self.update_global_license_file_status()
        # Update dasebase due to project upgrade
        need_upgrade = compare_versions(global_data.get("cloud_func_version", "1.0.0"), CLOUD_FUNC_VERSION)
        if need_upgrade:
            self.upgrade_database()

        instance_data = {
                        "instance_id": self.instance_id,
                        "instance_ip_list": instance_ip_list,
                        "is_primary": is_primary,
                        "management_port": MANAGEMENT_PORT,
                        "timestamp": timestamp
                        }
        if behavior == "insert":
            self.db.add_document(self.instance_name, instance_data)
        elif behavior == "update":
            self.db.update_document(self.instance_name, instance_data)
            instance_data = self.db.get_document(self.instance_name)
        cloud_func_port_id = get_port_id(CLOUD_FUNC_INTERFACE, 0)
        config_module = FortiGateConfig(instance_ip_list[cloud_func_port_id], self.instance_name, login_port=MANAGEMENT_PORT,
                                        log_level=LOGGING_LEVEL, username="admin", password=INSTANCE_PASSWORD)
        status, response = config_module.change_init_password(self.instance_id, INSTANCE_PASSWORD)
        self.print(f"Change password done {status}", "INFO")
        self.print(f"Change password done {status} {response.text}", "DEBUG")

        # Upload license
        if LICENSE_SOURCE in ["fortiflex", "file", "file_fortiflex"]:
            response_text = ""
            if LICENSE_SOURCE in ["file", "file_fortiflex"]:
                pre_assigned_file = instance_data.get("license_file", "")
                status, license_data = self.file_license_assign(pre_assigned_file)
                if status:
                    status, response = config_module.upload_license("file", license_data)
                    response_text = response.text
            if LICENSE_SOURCE == "fortiflex" or (LICENSE_SOURCE == "file_fortiflex" and not status):
                foritflex = FortiFlex(username=FORTIFLEX_USERNAME,
                                      password=FORTIFLEX_PASSWORD,
                                      task_name="GCP:"+self.instance_name)
                entitlement = {}
                pre_assigned_serial_number = instance_data.get("serial_number", "")
                if pre_assigned_serial_number:
                    self.print(f"Using previous serial number {pre_assigned_serial_number}", "DEBUG")
                    entitlement = foritflex.refresh_token(pre_assigned_serial_number)
                if not entitlement:
                    entitlement = foritflex.retrieve_unused_entitlement(FORTIFLEX_CONFIG, mode=FORTIFLEX_RETRIEVE_MODE, concurrent_mode=FORTIFLEX_CONCURRENT_MODE)
                status = (entitlement != {})
                self.print(f"Get entitlement {entitlement}", "DEBUG")
                if status:
                    license_data = entitlement["token"]
                    self.db.update_document(self.instance_name, {"serial_number": entitlement["serialNumber"],
                                                                 "config_id": entitlement["configId"],
                                                                 "license_source": "fortiflex"})
                    status, response = config_module.upload_license("fortiflex", license_data)
                    response_text = response.text
            self.print(f"Upload license done {status}", "INFO")
            self.print(f"Upload license done {status} {response_text}", "DEBUG")

            if not status:
                self.print("License injection fail, return.", "ERROR")
                return
            self.print("FGT rebooting, sleep 80s", "INFO")
            time.sleep(80)

        # Configuration data
        self.upload_fgt_init_config(instance, config_module, is_primary)

    def instance_delete(self):
        """   
        Update database, release license when instance is deleted.
        """
        # Update dasebase due to project upgrade
        global_data = self.db.get_document("GLOBAL")
        if global_data is not None:
            need_upgrade = compare_versions(global_data.get("cloud_func_version", "1.0.0"), CLOUD_FUNC_VERSION)
            if need_upgrade:
                self.upgrade_database()
        instance_data = self.db.get_document(self.instance_name)
        if instance_data is None:
            instance_data = {}
        license_source = instance_data.get("license_source", "")
        if license_source == "fortiflex": # Release fortiflex token
            config_id = instance_data.get("config_id", "")
            serial_number = instance_data.get("serial_number", "")
            foritflex = FortiFlex(username=FORTIFLEX_USERNAME,
                                  password=FORTIFLEX_PASSWORD,
                                  task_name="GCP:"+self.instance_name)
            if not (config_id and serial_number):
                entitlement = foritflex.get_entitlement(FORTIFLEX_CONFIG, description="GCP:"+self.instance_name)
                if entitlement:
                    config_id = entitlement.get("configId", "")
                    serial_number = entitlement.get("serialNumber", "")
            if config_id and serial_number:
                foritflex.release_used_entitlement(serial_number, config_id, mode=FORTIFLEX_RETRIEVE_MODE, concurrent_mode=FORTIFLEX_CONCURRENT_MODE)
        elif license_source == "file": # Release license file
            status = self.file_license_release(instance_data)
            self.print(f"Release instance with file {status}", "INFO")
        self.print(f"Release instance finished with method {license_source}", "INFO")
        self.db.delete_document(self.instance_name)
        # If the global data is the only thing left behind, delete the whole dataset
        current_doc_number = self.db.get_document_number()
        if current_doc_number==1 and self.db.get_document("GLOBAL") is not None:
            self.db.delete_document("GLOBAL")
        # If this instance is primary, reselect primary.
        delete_primary = instance_data.get("is_primary", False)
        if delete_primary and current_doc_number>1:            
            # Wait 10 seconds. If other instances are also shut down, the other
            # Cloud Functions threads will delete them from the database within 10 seconds.
            time.sleep(10)
            if self.db.get_document_number()>1:
                status, reselect_primary_id = self.reselect_primary_fgt()
                self.print(f"Reselect primary {status} {reselect_primary_id}", "INFO")

    def upload_fgt_init_config(self, instance, config_module, is_primary):
        subnetwork_client = compute_v1.SubnetworksClient()
        config_data = "# Following code updated by cloud functions\n"
        interface_list = []
        for i, interface in enumerate(instance.network_interfaces):
            subnet_self_link = interface.subnetwork
            subnetwork_region = get_key_from_url(subnet_self_link, "regions")
            subnetwork_name = get_key_from_url(subnet_self_link, "subnetworks")
            subnetwork = subnetwork_client.get(project=self.project_id, region=subnetwork_region, subnetwork=subnetwork_name)
            interface_list.append({"ip_cidr_range": subnetwork.ip_cidr_range,
                                   "gateway_address": subnetwork.gateway_address,
                                   "subnet_name": subnetwork.name,
                                   "network_ip": interface.network_i_p,
                                   "port": "port"+str(i+1)})
        global_data = self.db.get_document("GLOBAL")
        default_route_interface = DEFAULT_ROUTE_INTERFACE
        route_port_id = get_port_id(default_route_interface, -1)
        if route_port_id != -1:
            interface_list[route_port_id]["is_default_port"] = True
        ilb_ip_list = parse_json_str(ILB_IP_LIST, [])
        elb_ip_list = parse_json_str(ELB_IP_LIST, [])
        for i, interface in enumerate(instance.network_interfaces):
            ilb_ip = get_list_element(ilb_ip_list, i, "")
            if ilb_ip:
                interface_list[i]["ilb_ip"] = ilb_ip
            elb_ip = get_list_element(elb_ip_list, i, "")
            if elb_ip:
                interface_list[i]["elb_ip"] = elb_ip
        # Try to phrase interface data
        user_data = ""
        for key_value in instance.metadata.items:
            if key_value.key == "user-data":
                user_data = key_value.value
        interface_list = phrase_interface_allowaccess(user_data, interface_list)

        ha_port_id = get_port_id(HA_SYNC_INTERFACE, 1)
        primary_sync_ip = global_data["primary_ip_list"][ha_port_id]
        config_data += config_system_autoscale(is_primary, HA_SYNC_INTERFACE, AUTOSCALE_PSKSECRET, primary_sync_ip)
        config_data += config_system_interface(interface_list)
        config_data += config_router_static(interface_list)
        config_data += config_api_user()

        self.print(f"config data {config_data}", "DEBUG")
        status, response = config_module.upload_config(config_data)
        self.print(f"Upload config done {status}", "INFO")
        self.print(f"Upload config done {status} {response.text}", "DEBUG")
        self.db.update_document(self.instance_name, {"upload_config_status": status})

    def file_license_assign(self, pre_assigned_file=""):
        """
        Assign license for current instance, and return license data.
        """
        if pre_assigned_file != "":
            storage_client = storage.Client(project=self.project_id)
            bucket = storage_client.get_bucket(BUCKET_NAME)
            license_data = bucket.blob(pre_assigned_file).download_as_bytes()
            if license_data != "":
                return True, license_data
        lock_status, global_data = self.db.lock("GLOBAL", self.instance_name)
        if not lock_status or not isinstance(global_data, dict):
            return False, ""
        license_file_status = global_data.get("license_file_status")
        license_data = ""
        for license_file, owner_id in license_file_status.items():
            if owner_id == "":
                target_file = license_file
                license_file_status[license_file] = self.instance_name
                self.db.update_document("GLOBAL", {"license_file_status": license_file_status})
                self.db.update_document(self.instance_name, {"license_file": target_file, "license_source": "file"})
                storage_client = storage.Client(project=self.project_id)
                bucket = storage_client.get_bucket(BUCKET_NAME)
                license_data = bucket.blob(target_file).download_as_bytes()
                break
        self.db.unlock("GLOBAL", self.instance_name)
        return license_data!="", license_data

    def file_license_release(self, instance_data={}):
        if not instance_data:
            instance_data = self.db.get_document(self.instance_name)
            if not instance_data:
                return False
        license_file = instance_data.get("license_file", "")
        self.db.update_document(self.instance_name, {"license_file": ""})
        if license_file:
            lock_status, global_data = self.db.lock("GLOBAL", self.instance_name)
            if not lock_status or not isinstance(global_data, dict):
                return False
            license_file_status = global_data.get("license_file_status", {})
            license_file_status[license_file] = ""
            # Go through the whole list, just to avoid more than one license files are assigned to this instance due to some strange Bugs.            
            for license_file_name, owner_id in license_file_status.items():
                if owner_id == self.instance_name:
                    license_file_status[license_file_name] = ""
            self.db.update_document("GLOBAL", {"license_file_status": license_file_status})
            self.db.unlock("GLOBAL", self.instance_name)
        return True

    def reselect_primary_fgt(self):
        """
        If primary instance is destroied, reselect a new primary based on created time.
        """
        lock_status, global_data = self.db.lock("GLOBAL", self.instance_name)
        if not lock_status or not isinstance(global_data, dict):
            return False, ""

        new_primary_fgt_name = ""
        new_primary_fgt_id = ""
        primary_sync_ip = ""
        least_time = float("+inf")
        docs = self.db.collection_ref.get()
        for doc in docs:
            if doc.id == "GLOBAL":
                continue
            instance_creation_time = doc.to_dict().get("timestamp", float("+inf"))
            instance_creation_time = float(instance_creation_time)
            if instance_creation_time < least_time:
                least_time = instance_creation_time
                new_primary_fgt_name = doc.id
                new_primary_fgt_id = doc.to_dict().get("instance_id", "")
        if new_primary_fgt_name:
            instance_data = self.db.get_document(new_primary_fgt_name)
            instance_ip_list = instance_data.get("instance_ip_list", ["", ""])
            ha_port_id = get_port_id(HA_SYNC_INTERFACE, 1)
            primary_sync_ip = instance_ip_list[ha_port_id]
            self.db.update_document("GLOBAL", {"primary_instance_id": new_primary_fgt_id,
                                               "primary_instance_name": new_primary_fgt_name,
                                               "primary_ip_list": instance_ip_list})
            self.db.update_document(new_primary_fgt_name, {"is_primary": True})
        self.db.unlock("GLOBAL", self.instance_name)
        # reupload config
        if new_primary_fgt_name:
            import threading
            threads = []
            for doc in docs:
                if doc.id == "GLOBAL":
                    continue
                instance_data = doc.to_dict()
                if "upload_config_status" not in doc.to_dict():
                    # This is new instance. It will be updated in upload_fgt_init_config function
                    continue
                instance_name = str(doc.id)
                is_primary = (new_primary_fgt_name==doc.id)
                thread = threading.Thread(target=self.thread_reselect_primary_upload_config,
                                          args=(instance_name, instance_data, is_primary, HA_SYNC_INTERFACE, primary_sync_ip))
                threads.append(thread)
                thread.start()
            for thread in threads:
                thread.join()
        return new_primary_fgt_name!="", new_primary_fgt_name
    
    def thread_reselect_primary_upload_config(self, instance_name, instance_data, is_primary, ha_sync_interface, primary_sync_ip):
        instance_ip_list = instance_data.get("instance_ip_list", "")
        cloud_func_port_id = get_port_id(CLOUD_FUNC_INTERFACE, 0)
        config_module = FortiGateConfig(instance_ip_list[cloud_func_port_id], "ReselectPrimary-" + instance_name, login_port=MANAGEMENT_PORT,
                                        log_level=LOGGING_LEVEL, username="admin", password=INSTANCE_PASSWORD,
                                        api_token=API_USER_TOKEN)
        config_data = config_system_autoscale(is_primary, ha_sync_interface, AUTOSCALE_PSKSECRET, primary_sync_ip)
        status, response = config_module.upload_config(config_data)
        return status, response

    def update_global_license_file_status(self):
        storage_client = storage.Client(project=self.project_id)
        bucket = storage_client.get_bucket(BUCKET_NAME)
        license_file_status = {}
        blobs = bucket.list_blobs()
        for blob in blobs:
            file_path = blob.name
            if file_path.startswith("licenses/"):
                license_file_status[file_path] = ""
        self.db.update_document("GLOBAL", {"license_file_status": license_file_status})

    def print(self, print_str, log_level="INFO"):
        print_str = f"[{self.instance_name}] " + print_str.replace("\n", "\\n")
        print_log(print_str, log_level)

# Update config data
def config_system_autoscale(is_primary, ha_sync_interface, AUTOSCALE_PSKSECRET, primary_sync_ip=""):
    config_data = f"config system auto-scale\n"
    config_data += f"    set status enable\n"
    config_data += f"    set sync-interface {ha_sync_interface}\n"
    if is_primary:
        config_data += f"    set role primary\n"
    else:
        config_data += f"    set role secondary\n"
        config_data += f"    set primary-ip {primary_sync_ip}\n"
    config_data += f"    set psksecret '{AUTOSCALE_PSKSECRET}'\n"
    config_data += f"end\n"
    return config_data

def config_system_interface(interface_list):
    config_data = f"config system interface\n"
    has_probe = False
    for interface_info in interface_list:
        config_data += f"    edit {interface_info['port']}\n"
        config_data += f"        set mode static\n"
        config_data += f"        set ip {interface_info['network_ip']}/32\n"
        if "allowaccess" in interface_info:
            config_data += f"        " + interface_info["allowaccess"] + "\n"
        else:
            config_data += f"        set allowaccess ping https ssh http fgfm probe-response\n"
        secondary_ip = interface_info.get("elb_ip", interface_info.get("ilb_ip", ""))
        if secondary_ip:
            has_probe = True
            config_data += f"        set secondary-IP enable\n"
            config_data += f"        config secondaryip\n"
            config_data += f"            edit 0\n"
            config_data += f"                set ip {secondary_ip}/32\n"
            config_data += f"                set allowaccess ping probe-response\n"
            config_data += f"            next\n"
            config_data += f"        end\n"
        config_data += f"    next\n"
    config_data += f"end\n"
    if has_probe:
        config_data += f"config system probe-response\n"
        config_data += f"    set mode http-probe\n"
        config_data += f"end\n"
    return config_data

def config_router_static(interface_list):
    config_data = f"config router static\n"
    for interface_info in interface_list:
        if interface_info.get("is_default_port", False):
            config_data += f"    edit 0\n"
            config_data += f"        set device {interface_info['port']}\n"
            config_data += f"        set gateway {interface_info['gateway_address']}\n"
            config_data += f"        set comment 'Default route. (Created by cloud function)'\n"
            config_data += f"    next\n"
        if interface_info.get("ilb_ip", ""):
            config_data += f"    edit 0\n"
            config_data += f"        set dst 35.191.0.0/16\n"
            config_data += f"        set device {interface_info['port']}\n"
            config_data += f"        set gateway {interface_info['gateway_address']}\n"
            config_data += f"        set comment 'Used for ilb health check. (Created by cloud function)'\n"
            config_data += f"    next\n"
            config_data += f"    edit 0\n"
            config_data += f"        set dst 130.211.0.0/22\n"
            config_data += f"        set device {interface_info['port']}\n"
            config_data += f"        set gateway {interface_info['gateway_address']}\n"
            config_data += f"        set comment 'Used for ilb health check. (Created by cloud function)'\n"
            config_data += f"    next\n"
        config_data += f"    edit 0\n"
        config_data += f"        set dst {interface_info['ip_cidr_range']}\n"
        config_data += f"        set device {interface_info['port']}\n"
        config_data += f"        set gateway {interface_info['gateway_address']}\n"
        config_data += f"        set comment '(Created by cloud function)'\n"
        config_data += f"    next\n"
    config_data += f"end\n"
    return config_data

def config_api_user():
    config_data = ""
    if API_USER_TOKEN:
        config_data += f"config system api-user\n"
        config_data += f"    edit gcp_function_user\n"
        config_data += f"        set comments \"GCP Cloud Functions uses this user for autoscaling configuration.\"\n"
        config_data += f"        set api-key {API_USER_TOKEN}\n"
        config_data += f"    next\n"
        config_data += f"end\n"
    return config_data

def phrase_interface_allowaccess(user_data, interface_list):
    try:
        user_data_list = user_data.split("\n")
        search_system_interface = False
        current_port = -1
        for line in user_data_list:
            line = ' '.join(line.split()) # remove extra space
            if line == "config system interface":
                search_system_interface = True
            if search_system_interface:
                if line == "end":
                    search_system_interface = False
                    current_port = -1
                elif line.startswith("edit port"):
                    current_port = int(line[len("edit port"):]) - 1
                elif line.startswith("set allowaccess"):
                    if "probe-response" not in line:
                        line += " probe-response"
                    if 0 <= current_port < len(interface_list):
                        interface_list[current_port]["allowaccess"] = line
    except:
        pass
    return interface_list

from google.cloud import firestore
import time

class FirestoreWrapper:
    def __init__(self, project_id, collection, database="(default)"):
        self.db = firestore.Client(project=project_id, database=database)
        self.collection_ref = self.db.collection(collection)

    def get_document(self, document_name):
        doc_ref = self.collection_ref.document(document_name)
        doc = doc_ref.get()
        if doc.exists:
            return doc.to_dict()
        else:
            return None

    def add_document(self, document_name, data):
        doc_ref = self.collection_ref.document(document_name)
        if not doc_ref.get().exists:
            doc_ref.set(data)

    def set_document(self, document_name, data):
        doc_ref = self.collection_ref.document(document_name)
        doc_ref.set(data)

    def update_document(self, document_name, new_data):
        doc_ref = self.collection_ref.document(document_name)
        doc_ref.update(new_data)

    def delete_document(self, document_name):
        self.collection_ref.document(document_name).delete()

    def get_document_number(self):
        docs = self.collection_ref.stream()
        docs_count = sum(1 for _ in docs)
        return docs_count

    def lock(self, document_name, id, retry_time=5):
        for i in range(retry_time):
            data = self.get_document(document_name)
            if isinstance(data, dict):
                document_current_owner = data.get("lock_id", "")
                if document_current_owner == id:  # Already own it
                    return True, data
                if document_current_owner == "":  # Try to lock it
                    self.update_document(document_name, {"lock_id": id})
                    time.sleep(1)
                    refresh_data = self.get_document(document_name)
                    if refresh_data:
                        document_refresh_owner = refresh_data.get("lock_id", "")
                        if document_refresh_owner == id:
                            return True, refresh_data
            time.sleep(1)
        return False, data
    
    def unlock(self, document_name, id):
        data = self.get_document(document_name)
        document_current_owner = data.get("lock_id", "")
        if document_current_owner == id:
            self.update_document(document_name, {"lock_id": ""})
            return True
        return False
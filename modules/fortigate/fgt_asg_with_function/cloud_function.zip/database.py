from google.cloud import firestore
import time

class FirestoreWrapper:
    """
    CRUD Firestore database.
    """
    def __init__(self, project_id, collection, database="(default)"):
        self.db = firestore.Client(project=project_id, database=database)
        self.collection_ref = self.db.collection(collection)

    def read_document(self, document_name, collection_ref=None):
        if collection_ref is None:
            collection_ref = self.collection_ref
        doc_ref = collection_ref.document(document_name)
        doc = doc_ref.get()
        return doc.to_dict() if doc.exists else {}

    def create_document(self, document_name, data, collection_ref=None):
        """
        This function creates an new document.
        """
        if collection_ref is None:
            collection_ref = self.collection_ref
        doc_ref = collection_ref.document(document_name)
        try:
            doc_ref.create(data)
        except Exception as e:
            print(f"[Firestore] Error creating document {document_name}: {e}")

    def set_document(self, document_name, data, collection_ref=None):
        """
        This function overwrites all data of an existing document.
        """
        if collection_ref is None:
            collection_ref = self.collection_ref
        doc_ref = collection_ref.document(document_name)
        doc_ref.set(data)

    def update_document(self, document_name, new_data, collection_ref=None):
        """
        This function can update part of the data of an existing document.
        """
        if collection_ref is None:
            collection_ref = self.collection_ref
        doc_ref = collection_ref.document(document_name)
        try:
            doc_ref.update(new_data)
        except Exception as e:
            print(f"[Firestore] Error updating document {document_name}: {e}")

    def delete_document(self, document_name, collection_ref=None):
        if collection_ref is None:
            collection_ref = self.collection_ref
        collection_ref.document(document_name).delete()

    def get_document_number(self, collection_ref=None):
        if collection_ref is None:
            collection_ref = self.collection_ref
        docs = collection_ref.stream()
        docs_count = sum(1 for _ in docs)
        return docs_count

    def delete_collection(self, collection_ref, batch_size=100):
        while True:
            docs = collection_ref.limit(batch_size).stream()
            deleted = 0
            for doc in docs:
                doc.reference.delete()
                deleted += 1
            if deleted < batch_size:
                break

    @firestore.transactional
    def lock_transaction(transaction, document_name, id, collection_ref):
        doc_ref = collection_ref.document(document_name)
        doc = doc_ref.get(transaction=transaction)
        data = doc.to_dict() if doc.exists else {}
        if isinstance(data, dict):
            if data.get("lock_id", "") == "":
                transaction.update(doc_ref, {"lock_id": id})
                return True, data
            elif data.get("lock_id", "") == id:
                return True, data
        return False, data

    def lock(self, document_name, id, retry_time=10, sleep_interval=1, collection_ref=None):
        if collection_ref is None:
            collection_ref = self.collection_ref
        data = {}
        for _ in range(retry_time):
            try:
                success, data = self.lock_transaction(self.db.transaction(), document_name, id, collection_ref)
                if success:
                    return True, data
            except Exception as e:
                print(f"[Firestore] Error acquiring lock {document_name}, retrying...: {e}")
            time.sleep(sleep_interval)
        return False, data

    @firestore.transactional
    def unlock_transaction(transaction, document_name, id, collection_ref):
        doc_ref = collection_ref.document(document_name)
        doc = doc_ref.get(transaction=transaction)
        data = doc.to_dict() if doc.exists else {}
        if data and data.get("lock_id", "") == id:
            transaction.update(doc_ref, {"lock_id": ""})  # Use transaction update
            return True
        return False

    def unlock(self, document_name, id, collection_ref=None):
        if collection_ref is None:
            collection_ref = self.collection_ref
        try:
            return self.unlock_transaction(self.db.transaction(), document_name, id, collection_ref)
        except Exception as e:
            print(f"[Firestore] Error releasing lock {document_name}: {e}")
            return False

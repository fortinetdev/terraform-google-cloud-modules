import requests
import time
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

class FortiAnalyzerConfig:
    """
    This class is used to communicate with FAZ/FMG through https port.
    """
    def __init__(self, host_ip, username="admin", password="",
                 log_header="", log_level="NONE", access_token=None):
        self.host_ip = host_ip
        self.username = username
        self.password = password
        self.print_log_level = self._get_log_level(log_level, default_level=0)
        self.log_header = log_header
        self.timeout_sec = 10
        self._session = None
        self._access_token = access_token
        self.status = False
        self.login()

    def assemble_data(self, method, url, jsonrpc2=False, **params):
        json_data = {
            "method": method,
            "verbose": 1
        }
        json_data["params"] = [params]
        json_data["params"][0]["url"] = url
        if self._session:
            json_data["session"] = self._session
        if jsonrpc2:
            json_data["jsonrpc"] = "2.0"
            json_data["params"][0]["apiver"] = 3
        return json_data

    def send_one_request(self, json_data, timeout=10, request_name="", attempt_id=0):
        log_header = ""
        if request_name:
            log_header = f"[{request_name}] "
        log_header += f"[ATTEMPT {attempt_id}] "
        response = requests.Response()
        response_data = {}
        header = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        url = f"https://{self.host_ip}/jsonrpc"
        if self._access_token:
            url += f"?access_token={self._access_token}"
            header["Authorization"] = f"Bearer {self._access_token}"
        try:
            self._log(f"{log_header}[Requst] {json_data}", "TRACE")
            response = requests.post(url, headers=header, json=json_data, verify=False, timeout=timeout)
        except Exception as e:
            self._log(f"{log_header}Failed to send request. {e}","ERROR")
            return -1, ""
        try:
            response_data = response.json()
            self._log(f"{log_header}[Response] {response_data}", "TRACE")
        except Exception as e:
            self._log(f"{log_header}Failed to load response {response.text} | {e}","ERROR")
        return response.status_code, response_data
    
    def send_requests(self, json_data, request_name="", max_attempt=5, sleep_time=5, timeout=10,
                      success_api_rc=[0]):
        log_header = ""
        if request_name:
            log_header = f"[{request_name}] "
        attempt_id = 0
        response_rc = None
        api_rc = -643284 # special code (random selected). Stand for no data.
        api_msg = "no message"
        while attempt_id < max_attempt:
            attempt_id += 1
            response_rc, response_json = self.send_one_request(json_data, request_name=request_name,
                                                               attempt_id=attempt_id, timeout=timeout)
            if response_rc not in [200]:
                # can't access FAZ/FMG
                self._log(f"{log_header}HTTPS error. Code: {response_rc}. Message: {response_json}", "TRACE")
                if attempt_id < max_attempt:
                    time.sleep(sleep_time)
                continue
            api_rc, api_msg = self._check_error(response_json)
            if api_rc not in success_api_rc:
                self._log(f"{log_header}JSON API error. Code: {api_rc}. Message: {api_msg}", "TRACE")
                if attempt_id < max_attempt:
                    time.sleep(sleep_time)
                continue
            break
        if api_rc != 0 and api_rc in success_api_rc:
            self._log(f"{log_header}Get return code {api_rc}. It is considered as success in this task.", "DEBUG")            
        if response_rc in [200] and api_rc in success_api_rc:
            self._log(f"{log_header}Task successed.", "DEBUG")
        else:
            error_log = f"{log_header}Task Failed. HTTPS code: {response_rc}, API code: {api_rc}"
            if api_msg != "no message":
                error_log += f", API message: {api_msg}"
            self._log(error_log, "DEBUG")
        return api_rc, response_json

    def login(self):
        # Using user/passwd
        if self.password:
            data = {"passwd":self.password, "user":self.username}
            json_data = self.assemble_data("exec", "/sys/login/user", data=data)
            api_rc, response_json = self.send_requests(json_data, request_name="LOGIN")
            if api_rc == 0:
                self._session = response_json.get("session", None)
                self.status = True
        # Using access token
        if self.status == False and self._access_token:
            json_data = self.assemble_data("get", "/sys/status")
            api_rc, response_json = self.send_requests(json_data, request_name="Check access_token")
            if api_rc == 0:
                self.status = True

    def logout(self):
        if self._session:
            json_data = self.assemble_data("exec", "/sys/logout")
            self.send_requests(json_data, request_name="LOGOUT", max_attempt=1)

    def task_add_device(self, fgt_hostname, faz_adom="root", faz_username="", faz_password=""):
        """
        Possible return code and their meaning:
        0: Success
        -20031: Serial number does not match device model. E.g, fgt_hostname is wrong.
        -20002: Invalid argument. E.g., faz_adom is wrong.
        Adding an already authorized device will also get code 0.
        """
        if faz_username == "":
            faz_username = self.username
        if faz_password == "":
            faz_password = self.password
        data = {
            "adom": faz_adom,
            "device": {
                "adm_pass": [faz_password],
                "adm_usr": faz_username,
                "device action": "promote_unreg",
                "name": fgt_hostname,
            }
        }
        json_data = self.assemble_data("exec", "/dvm/cmd/add/device", data=data)
        api_rc, response_json = self.send_requests(json_data, request_name="Add Device")
        return api_rc, response_json
    
    def task_delete_device(self, fgt_hostname, faz_adom="root"):
        """
        Possible return code and their meaning:
        0: Success
        -20002: Invalid argument. E.g., This device is not existed in the faz database.
        Deleting an already deleted device will get code -20002.
        """
        data = {
            "adom": faz_adom,
            "device": fgt_hostname
        }
        json_data = self.assemble_data("exec", "/dvm/cmd/del/device", data=data)
        api_rc, response_json = self.send_requests(json_data, request_name="Delete Device", max_attempt=10)
        return api_rc, response_json

    def _check_error(self, response):
        '''
        Get the code and message from the return data
        '''
        result = response.get("result", [{}])
        status = result[0].get("status", {})
        code = status.get("code", -643284) # special code (random selected) for no data
        message = status.get("message", "no message")
        return code, message
    
    def _log(self, log_str, log_level="INFO"):
        log_level_int = self._get_log_level(log_level, default_level=3)
        if self.print_log_level>=log_level_int:
            print(f"[{log_level}] [{self.log_header}] [FAZ] {log_str}")

    def _get_log_level(self, log_str, default_level=0):
        log_level = {"TRACE": 5, "DEBUG":4, "INFO":3, "WARN": 2, "ERROR": 1, "NONE": 0}
        if log_str is None:
            return default_level
        if isinstance(log_str, int):
            return log_str
        if isinstance(log_str, str):
            if log_str.isdigit():
                return int(log_str)
            return log_level.get(log_str, default_level)
        return default_level

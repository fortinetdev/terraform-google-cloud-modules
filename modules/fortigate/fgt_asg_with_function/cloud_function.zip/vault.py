# This file is for connecting to the Hashicorp Vault
from utils import get_env_variable, print_log
import requests

VAULT_SERVER = get_env_variable("VAULT_SERVER") # The https://IP:port of the VAULT_SERVER, e.g., https://123.123.123.123:8200
VAULT_ROLE = get_env_variable("VAULT_ROLE") # The role to login the vault server
VAULT_PATH = get_env_variable("VAULT_PATH") # The path in the Vault server where save the data

VAULT_ENABLE = False
if VAULT_SERVER and VAULT_ROLE and VAULT_PATH:
    VAULT_ENABLE = True

def vault_generate_gcp_jwt():
    """
    Generate JWT from the GCP metadata server
    """
    # Set the target audience
    audience = f"{VAULT_SERVER}/vault/{VAULT_ROLE}"

    # Call the GCP metadata server to generate JWT
    metadata_url = (
        f"http://metadata/computeMetadata/v1/instance/service-accounts/default/identity"
        f"?audience={audience}&format=full"
    )
    headers = {"Metadata-Flavor": "Google"}
    response = requests.get(metadata_url, headers=headers)
    response.raise_for_status()
    return response.text  # Return the JWT


def vault_login(jwt, log_header=""):
    """
    Login to Vault using the generated JWT and retrieve Vault Token
    """
    login_url = f"{VAULT_SERVER}/v1/auth/gcp/login"
    payload = {
        "role": VAULT_ROLE,
        "jwt": jwt
    }
    response = requests.post(login_url, json=payload, verify=False)  # verify=False skips HTTPS certificate verification
    print_log(response.text, "TRACE", log_header)
    response.raise_for_status()  # Check response status
    return response.json()["auth"]["client_token"]

def vault_read_secret(vault_token, log_header=""):
    """
    Use the Vault Token to read data from the Secrets Engine
    """
    secret_url = f"{VAULT_SERVER}/v1/{VAULT_PATH}"
    headers = {"X-Vault-Token": vault_token}
    response = requests.get(secret_url, headers=headers, verify=False)
    print_log(response.text, "TRACE", log_header)
    response.raise_for_status()  # Check response status
    return response.json()["data"]["data"]  # Return secret data

def vault_connect(log_header=""):
    vault_secrets = {}
    print_log(f"Connecting Vault {VAULT_SERVER} {VAULT_ROLE} {VAULT_PATH}.", "DEBUG", log_header)
    try:
        jwt = vault_generate_gcp_jwt()
        print_log(f"Get JWT token: {jwt}", "TRACE", log_header)
        vault_token = vault_login(jwt, log_header)
        print_log(f"Get Vault login token: {vault_token}", "TRACE", log_header)
        vault_secrets = vault_read_secret(vault_token, log_header)
        print_log(f"Read Vault secrets: {vault_secrets}", "TRACE", log_header)
        print_log(f"Read vault secrets success.", "DEBUG", log_header)
    except Exception as e:    
        print_log(f"Skip Vault connection. Error when connecting to Vault: {e}.", "ERROR", log_header)
    return vault_secrets

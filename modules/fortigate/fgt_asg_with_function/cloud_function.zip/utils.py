import os
import re
import json

def get_env_variable(variable_name, default_value=None):
    value = os.getenv(variable_name)
    if value is None:
        value = default_value
    return value

def get_log_level(log_str, default_level=0):
    log_level = {"TRACE": 5, "DEBUG":4, "INFO":3, "WARN": 2, "ERROR": 1, "NONE": 0}
    if log_str is None:
        return default_level
    if isinstance(log_str, int):
        return log_str
    if isinstance(log_str, str):
        if log_str.isdigit():
            return int(log_str)
        return log_level.get(log_str.upper(), default_level)
    return default_level        

def print_log(print_str, log_level="INFO", log_header=""):
    log_level_int = get_log_level(log_level, default_level=3)
    if LOGGING_LEVEL>=log_level_int:
        print_str = print_str.replace("\n", "\\n")
        if log_header:
            print(f"[{log_level}] {log_header} {print_str}")
        else:
            print(f"[{log_level}] {print_str}")

def get_key_from_url(url, key):
    match = re.search(key+"/([^/]+)", url)
    if match:
        return match.group(1)
    return ""

def get_port_id(interface_name, default_value=0):
    port_id = interface_name.replace("port", "")
    if port_id.isdigit():
        port_id = int(port_id) - 1
    else:
        port_id = default_value
    return port_id

def parse_json_str(json_str, default_value=None):
    try:
        result = json.loads(json_str)
        return result
    except Exception as e:
        return default_value

def get_list_element(list_data, index, default_value=None):
    try:
        return list_data[index]
    except Exception as e:
        return default_value

def compare_versions(version1, version2):
    v1 = list(map(int, version1.split('.')))
    v2 = list(map(int, version2.split('.')))
    max_length = max(len(v1), len(v2))
    v1.extend([0] * (max_length - len(v1)))
    v2.extend([0] * (max_length - len(v2)))
    for a, b in zip(v1, v2):
        if a < b:
            return True
        elif a > b:
            return False
    return False 

# General param
CLOUD_FUNC_VERSION = "1.4.2" # This version number equals to the version of the GCP Cloud Modules project.
PROJECT_PREFIX = get_env_variable("PROJECT_PREFIX")
LOGGING_LEVEL = get_log_level(get_env_variable("LOGGING_LEVEL"), default_level=3)

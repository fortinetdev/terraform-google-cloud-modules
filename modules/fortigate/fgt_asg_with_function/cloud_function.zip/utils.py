import os
import re

# General param
PROJECT_PREFIX = os.getenv("PROJECT_PREFIX")
PRINT_DEBUG_MSG = os.getenv("PRINT_DEBUG_MSG")


def debug_print(print_str):
    if PRINT_DEBUG_MSG:
        print(print_str.replace("\n", "\\n"))

def get_key_from_url(url, key):
    match = re.search(key+"/([^/]+)", url)
    if match:
        return match.group(1)
    return ""
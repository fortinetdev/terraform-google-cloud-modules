import requests
import time
import base64
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

class FortiGateConfig:
    """
    This class is used to communicate with FGT through https port.
    """
    def __init__(self, host_ip, log_header, login_port="",
                 username="admin", password="", api_token="", log_level="NONE"):
        self.host_ip = host_ip
        self.login_port = str(login_port)
        self.cookie = ""
        self.csrf_token = ""
        self.log_header = log_header
        self.timeout_sec = 10
        # Specify user/passwd in the beginning, so it is easy to relogin.
        self.username = username
        self.password = password
        self.api_token = api_token
        self.print_log_level = self._get_log_level(log_level, default_level=0)

    def send_one_request(self, url, header, data={}, request_name="", attempt_id=0, method="post"):
        response = requests.Response()
        self._log(f"[Task {request_name}] [Attempt {attempt_id}] [Request] URL {url} | Header {header} | DATA {data}", "DEBUG")
        try:
            if method=="post":
                response = requests.post(url, headers=header, json=data, verify=False, timeout=self.timeout_sec)
            elif method=="get":
                response = requests.get(url, headers=header, data=data, verify=False, timeout=self.timeout_sec)
            self._log("[Task {}] [Attempt {}] [Response] Code {} | Text {} | Header {}".format(request_name, attempt_id, response.status_code,
                                                                        str(response.text).replace("\n", ""),
                                                                        str(response.headers).replace("\n", "")),"DEBUG")
        except Exception as e:
            self._log(f"[Task {request_name}] [Attempt {attempt_id}] Fail, {e}.", "DEBUG")
        return response

    def send_request(self, url, header, data={}, request_name="", max_attempt=20, sleep_time=10,
                     success_rc=[200], relogin_rc=[401]):
        attempt_id = 0
        response = requests.Response()
        while attempt_id <= max_attempt and response.status_code not in success_rc:
            attempt_id += 1
            if self.api_token: # use token
                header["Authorization"] = f"Bearer {self.api_token}"
            else: # use username and password
                # If relogin_rc (usually 401), try to login again and get new cookie
                if attempt_id>1 and response.status_code in relogin_rc:
                    self._log("[Task {}] [Attempt {}] Login again due to last response is {}".format(request_name, attempt_id, response.status_code), "DEBUG")
                    self.login()
                if request_name not in ["login", "change_password", "change_password_logout"]:
                    header["Cookie"] = self.cookie
                    header["X-CSRFTOKEN"] = self.csrf_token
            response = self.send_one_request(url, header, data, request_name, attempt_id)
            if attempt_id == max_attempt or response.status_code in success_rc:
                break
            self._log(f"[Task {request_name}] [Attempt {attempt_id}] Sleep {sleep_time}s and retry", "DEBUG")
            time.sleep(sleep_time)
        if response.status_code in success_rc and response.status_code != 200:
            self._log(f"[Task {request_name}] Get a non-200 code: {response.status_code}, this code is considered as success for this task.", "DEBUG")            
        return response.status_code in success_rc, response

    def get_url(self, path):
        login_port = ""
        if self.login_port:
            login_port = ":" + self.login_port
        if not path.startswith("/"):
            path = "/" + path
        return "https://" + self.host_ip + login_port + path
    
    def login(self, username="", password=""):
        if not username:
            username = self.username
        if not password:
            password = self.password
        LOGIN_FORMAT = "logincheck?username={username}&secretkey={password}"
        url = self.get_url(LOGIN_FORMAT.format(username=username, password=password))
        header = {"Content-Type": "application/json"}
        status, response = self.send_request(url, header, request_name="login", relogin_rc=[])
        if response.status_code != 200:
            self._log("Cannot login {}".format(response.text), "ERROR")
            return False, response
        self._get_cookie_from_headers(response.headers)
        return status, response
    
    def upload_license(self, license_source, license_data):
        if license_source not in ["fortiflex", "file"]:
            return False, self._generate_response("variable LICENSE_SOURCE should be 'fortiflex' or 'file'.")
        status, response = self.login()
        if not status:
            return False, response
        header = {"Content-Type": "application/json"}
        if license_source == "fortiflex":
            body = {"token": license_data}
            url = self.get_url("/api/v2/monitor/system/vmlicense/download")
            status, response = self.send_request(url, header, data=body, request_name="upload_license_fortiflex", success_rc=[200,500])
            if response.status_code==500 and "License Token is already used" in response.text:
                return True, response
            return status, response
        elif license_source == "file":                
            body = {"file_content": self._base64_encode(license_data)}
            url = self.get_url("/api/v2/monitor/system/vmlicense/upload")
            return self.send_request(url, header, data=body, request_name="upload_license_file")
        return False, requests.Response()
    
    def upload_config(self, config_data, config_name = "config_data.conf"):
        if not self.api_token:
            status, response = self.login()
            if not status:
                return False, response
        header = {"Content-Type": "application/json"}
        encoded_config_data = self._base64_encode(config_data)
        body = {
            "filename": config_name,
            "file_content" : encoded_config_data
        }
        url = self.get_url("/api/v2/monitor/system/config-script/upload")
        status, response = self.send_request(url, header, data=body, request_name="upload_config", sleep_time=15, success_rc=[200,500])
        return status, response

    def change_init_password(self, old_password, new_password):
        url = self.get_url("/api/v2/authentication")
        header = {"Content-Type": "application/json"}
        body = {
            "username" : "admin",
            "secretkey" : old_password,
            "ack_pre_disclaimer" : True,
            "ack_post_disclaimer" : True,
            "new_password1" : new_password,
            "new_password2" : new_password,
            "request_key": True
        }
        attempt_id = 0
        max_attempt = 10  # set attempt number large just in case the FGT has long initial reboot time
        response = requests.Response()
        session_key = ""
        response_json = {}
        login_failed_counter = 0
        while attempt_id <= max_attempt:
            attempt_id += 1
            response = self.send_one_request(url, header, data=body, request_name="change_password", attempt_id=attempt_id)
            if response.status_code == 200:
                response_json = response.json()
                session_key = response_json.get("session_key", "")
                if session_key:
                    break
                if response_json.get("status_message", "LOGIN_FAILED"):
                    login_failed_counter += 1
                    # login failed 3 times, break (sometimes, it means the password is already changed)
                    if login_failed_counter == 3:
                        break
            time.sleep(20)
        if not session_key:
            self._log("can't get session key when changing password {}".format(response_json), "ERROR")
            return False, response
        body = {"session_key": session_key}
        self.send_request(url, header, data=body, request_name="change_password_logout", max_attempt=1, success_rc=[200,500])
        return True, response
    
    def _generate_response(self, response_text):
        response = requests.Response()
        response._content = response_text.encode('utf-8')
        response.encoding = 'utf-8'
        return response
    
    def _get_cookie_from_headers(self, header):
        cookie_data = ""
        for key in header:
            if key.lower() == "set-cookie":
                cookie_data = header[key]
                break
        cookie_list = cookie_data.split(",")
        cookie_list = [item.split(';')[0] for item in cookie_list]
        for item in cookie_list:
            if "ccsrftoken" in item:
                self.csrf_token = item.split("\"")[1]
        self.cookie = ";".join(cookie_list)
        
    def _base64_encode(self, data):
        if not isinstance(data, bytes):
            data = str(data).encode("ascii")
        return base64.b64encode(data).decode("ascii")

    def _log(self, log_str, log_level="INFO"):
        log_level_int = self._get_log_level(log_level, default_level=3)
        if self.print_log_level>=log_level_int:
            print(f"[{log_level}] [{self.log_header}] {log_str}")

    def _get_log_level(self, log_str, default_level=0):
        log_level = {"TRACE": 5, "DEBUG":4, "INFO":3, "WARN": 2, "ERROR": 1, "NONE": 0}
        if log_str is None:
            return default_level
        if isinstance(log_str, int):
            return log_str
        if isinstance(log_str, str):
            if log_str.isdigit():
                return int(log_str)
            return log_level.get(log_str, default_level)
        return default_level
